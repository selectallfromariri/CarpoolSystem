/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coffeebag;

/**
 *
 * @author harir
 */
public class CoffeeSales {
    public static void main(String[] args){
        CoffeeBag bag1 = new CoffeeBag();
        bag1.setCoffeeType("Arabic");
        bag1.setBagSold(2);
        bag1.setBagWeight(12.50);
        bag1.setpricePerKg(20.00);
        
        CoffeeBag bag2 = new CoffeeBag("Robusta", 3, 10.00, 15.00);
        CoffeeBag bag3 = new CoffeeBag("Liberica", 1, 1.00, 50.00);
        CoffeeBag bag4 = new CoffeeBag("Exelsa", 4, 5.00, 17.50);
        
        
        System.out.println("////RECEIPT/////");
        System.out.println("Coffee Type: "+ bag1.getCoffeeType());
        System.out.println("Number of bag: "+ bag1.getBagSold());
        System.out.println("Weight per Bag: "+ bag1.getbagWeight());
        System.out.println("Price per Kg: "+ bag1.getpricePerKg());
        System.out.println("Sales Tax: 7.25%");
        System.out.println("Total price with Tax: "+ bag1.TotalPriceWithTax());
        
        System.out.println("\nCoffee Type: "+ bag2.getCoffeeType());
        System.out.println("Number of bag: "+ bag2.getBagSold());
        System.out.println("Weight per Bag: "+ bag2.getbagWeight());
        System.out.println("Price per Kg: "+ bag2.getpricePerKg());
        System.out.println("Sales Tax: 7.25%");
        System.out.println("Total price with Tax: "+ bag2.TotalPriceWithTax());
        
        System.out.println("\nCoffee Type: "+ bag3.getCoffeeType());
        System.out.println("Number of bag: "+ bag3.getBagSold());
        System.out.println("Weight per Bag: "+ bag3.getbagWeight());
        System.out.println("Price per Kg: "+ bag3.getpricePerKg());
        System.out.println("Sales Tax: 7.25%");
        System.out.println("Total price with Tax: "+ bag3.TotalPriceWithTax());
        
        System.out.println("\nNumber of bag: "+ bag4.getBagSold());
        System.out.println("Weight per Bag: "+ bag4.getbagWeight());
        System.out.println("Price per Kg: "+ bag4.getpricePerKg());
        System.out.println("Sales Tax: 7.25%");
        System.out.println("Total price with Tax: "+ bag4.TotalPriceWithTax());
        
        
    }
}
