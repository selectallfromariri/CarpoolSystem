/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarysystemapp;

/**
 *
 * @author harir
 */
public class LibrarySystemApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Book b1 = new Book("B101", "Java Book", 2020, "Ali", "Malaysia");
        Book b2 = new Book("B102", "OOP Concept", 2021, "Siti", "Singapura");
        Book b3 = new Book("B103", "Data Structure", 2022, "Ahmad", "Malaysia");
        
        Book[] booklist = {b1, b2, b3};
        
        Library lib1 = new Library("UMPSA Library", booklist);
        System.out.println("\n==================");
        lib1.displayLibrary();
        System.out.println("\n==================");
        lib1.displayMalaysiaBook();
        System.out.println("\n");
        b2.updateAuthorCountry("Indonesia");
        System.out.println("===After Updating Author Country ===");
        lib1.displayLibrary();
        
    }
    
}
